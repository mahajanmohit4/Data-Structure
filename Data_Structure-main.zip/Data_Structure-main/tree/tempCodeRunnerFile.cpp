 if(root == NULL)
    {
        return createnode(input);
    }